from setuptools import setup, find_packages

setup(
    name="cs4789-pa1",
    version="0.0.1",
    packages=["cs4789-pa1"],
    python_requires=">=3.10",
    install_requires=[
        "numpy>=1.26.1",
        "matplotlib>=3.8.0",
    ],
)
